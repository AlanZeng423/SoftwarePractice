package com.neusoft.elmboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Elmboot2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
